// ������.cpp : �������̨Ӧ�ó������ڵ㡣
/*
�հ�0	����1	Ŀ��2	ǽ		������
0000	0001	0010	1000	0100
*/
#include "stdafx.h"
#include "stdafx.h"
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <time.h>
#include <string.h>
#pragma warning(disable:4996)
int map[100][17][17];
int lvl = 1;
typedef struct point{
	int x;
	int y;
}point;
void gotoxy(int x, int y)
{
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD pos;
	pos.X = x * 2;
	pos.Y = y;
	SetConsoleCursorPosition(hOut, pos);
}
char Button()
{
	char ch = getch();
	if(ch == -32)             //�����
	{
		ch = getch();
		if(ch == 72)return 'U';   //��
		if(ch == 80)return 'D';   //��
		if(ch == 75)return 'L';   //��
		if(ch == 77)return 'R';   //��
	}
	if(ch == 32)return ' ';	//�ո�
	return ch;
}
void Set()
{
	system("cls");
	printf("\n\t[A]ѡ���ɫ");
	printf("\n\t[L]ѡ��ؿ�");
	scanf("%d", &lvl);
}
void Drawmen()
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0XF9);
	printf("��");
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0XF4);
}
void Draw(int l)
{
	//�� �� �� ��
	gotoxy(0, 0);
	printf("�X�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�[");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�^�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�a");
	/*for(int j = 1; j <= 15; j++)
	for(int i = 1; i <= 15; i++){
		map[i][j] = 0;
	}*/
	for(int j = 1; j < 17; j++)
	for(int i = 1; i < 17; i++){
		if(map[l][i][j] == 8){
			gotoxy(i, j);
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0XF0);
			printf("��");
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0XF4);
		}
		if(map[l][i][j] == 1){
			gotoxy(i, j);
			printf("��");
		}
		if(map[l][i][j] == 3){
			gotoxy(i, j);
			printf("��");
		}
		if(map[l][i][j] == 2){
			gotoxy(i, j);
			printf("��");
		}
		if(map[l][i][j] == 4){
			gotoxy(i, j);
			Drawmen();
		}
	}
}
bool Check(int a[17][17])
{
	for(int j = 1; j <= 15; j++)
	for(int i = 1; i <= 15; i++)
	if((a[i][j] & 2) == 2)
	if((a[i][j] & 1) != 1)
		return false;
	return true;
}
void Start()
{
	int a[17][17] = { 0 };
	int x = 1, y = 1;
	while(1){
		system("cls");
		Draw(lvl);
		for(int j = 1; j <= 15; j++)
		for(int i = 1; i <= 15; i++){
			if(map[lvl][i][j] == 4){
				x = i;
				y = j;
				a[i][j] = 0;
			}
			else a[i][j] = map[lvl][i][j];
		}
		gotoxy(0, 18);
		printf("��%2d��", lvl);
		int step = 0;
		while(1){
			gotoxy(11, 18);
			printf("step:%2d",step);
			int ox = x, oy = y;
			switch(Button()){
			case 'U':y--; break;
			case 'D':y++; break;
			case 'L':x--; break;
			case 'R':x++; break;
			case 27:system("cls"); return;
			}
			if(!(x == ox && y == oy)){
				if(a[x][y] == 8){
					x = ox;
					y = oy;
				}
				else if((a[x][y] & 1) == 1){
					int i = x - ox, j = y - oy;
					if((a[x + i][y + j] & 9) == 0){
						step++;
						a[x + i][y + j] += 1;
						a[x][y] -= 1;
						gotoxy(x + i, y + j);
						if(a[x + i][y + j] == 3)printf("��");
						else printf("��");
						gotoxy(x, y);
						Drawmen();
						gotoxy(ox, oy);
						if((a[ox][oy] & 2) == 2)printf("��");
						else printf("  ");
						//����Ƿ����
						if(Check(a))break;
					}
					else{
						x = ox;
						y = oy;
					}
				}
				else if(a[x][y] == 0 || a[x][y] == 2){
					step++;
					gotoxy(x, y);
					Drawmen();
					gotoxy(ox, oy);
					if((a[ox][oy] & 2) == 2)printf("��");
					else printf("  ");
				}
			}
		}
		lvl++;
		gotoxy(0, 18);
		printf("��ϲ����,���س�������");
		while(Button() != 13);
	}

}
void Read()
{
	FILE *fp = fopen("boxmanmap.dat", "rb");
	if(fp == 0){
		system("cls");
		printf("ERROR:ȱ��boxmanmap.dat�ļ�!�뽫boxmanmap.dat�ͱ����������ͬһĿ¼��");
		getch();
		return;
	}
	fseek(fp, 0, 0);
	fread(map, sizeof(map), 1, fp);
	fclose(fp);
	system("color F4");
	while(1)
	{
		gotoxy(0, 18);
		printf("��%2d��", lvl);
		Draw(lvl);
		switch(Button()){
		case 'U':lvl++; break;
		case 'D':if(lvl>1)lvl--; break;
		case 13:
			Start();
			break;
		case 27:return;
		}
	}
}
void Bclear(int x, int y,int l, int map[100][17][17], int *box, int *place, int *men)
{
	if(map[l][x][y] == 1)(*box)--;
	if(map[l][x][y] == 2)(*place)--;
	if(map[l][x][y] == 4)(*men)--;
	if(map[l][x][y] == 3){
		(*box)--;
		(*place)--;
	}
}
void Building(int l)
{
	int box = 0;
	int place = 0;
	int men = 0;
	for(int j = 1; j <= 15; j++)
	for(int i = 1; i <= 15; i++){
		if(map[l][i][j] == 1)box++;
		if(map[l][i][j] == 2)place++;
		if(map[l][i][j] == 4)men++;
	}
	int x = 1, y = 1;
	gotoxy(x, y);
	printf("�I");
	gotoxy(0, 17);
	printf("[13]��[32]��   [X][V][A][C][Q][S]");
	while(1){
		int ox = x, oy = y;
		switch(Button()){
		case 'U':if(y > 1)y--; break;
		case 'D':if(y < 15)y++; break;
		case 'L':if(x > 1)x--; break;
		case 'R':if(x < 15)x++; break;
		case 'x':
		case 'X':
			Bclear(x, y, l, map, &box, &place, &men);
			place++;
			map[l][x][y] = 2; break;
		case 'a':
		case 'A':
			Bclear(x, y, l, map, &box, &place, &men);
			men++;
			map[l][x][y] = 4; break;
		case 13:
			Bclear(x, y, l, map, &box, &place, &men);
			box++;
			map[l][x][y] = 1; break;
		case ' ':
			Bclear(x, y, l, map, &box, &place, &men);
			map[l][x][y] = 8; break;
		case 'c':
		case 'C':
			Bclear(x, y, l, map, &box, &place, &men);
			map[l][x][y] = 0; break;
		case 'v':
		case 'V':
			Bclear(x, y, l, map, &box, &place, &men);
			place++;
			box++;
			map[l][x][y] = 3; break;
		case 27:system("cls"); return;
		case 'q':
		case 'Q':
			for(int j = 1; j <= 15; j++)
			for(int i = 1; i <= 15; i++)
				map[l][i][j] = 0;
			box = 0;
			place = 0;
			men = 0;
			Draw(l);
			break;
		case 's':
		case 'S':
			gotoxy(0, 18);
			if(box != place)printf("���������� ");
			if(men != 1)printf("���˹����� ");
			//fprintf(fp, "level\n");
			//fwrite(&map, 17 * 17, map[17][17], fp);
			FILE *fp = fopen("boxmanmap.dat", "wb");
			if(fwrite(map, sizeof(map), 1, fp) == 1)printf("д��ɹ�");
			fclose(fp);
			getch();
			system("cls");
			return;
		}
		if(!(x == ox && y == oy)){
			gotoxy(x, y);
			printf("�I");
			gotoxy(ox, oy);
			if(map[l][ox][oy] == 1)printf("��");
			else if(map[l][ox][oy] == 2)printf("��");
			else if(map[l][ox][oy] == 3)printf("��");
			else if(map[l][ox][oy] == 8)printf("��"); 
			else if(map[l][ox][oy] == 0)printf("  ");
			else if(map[l][ox][oy] == 4)printf("��");
		}
		gotoxy(0, 19);
		printf("map[%2d][%2d]:%2d    box:%2d place:%2d", x, y, map[l][x][y], box, place);
	}
}
void Bupdate()
{
	int l = 1;
	while(1)
	{
		gotoxy(0, 18);
		printf("��%2d��", l);
		Draw(l);
		switch(Button()){
		case 'U':l++; break;
		case 'D':if(l>0)l--; break;
		case 13:
			Building(l);
			break;
		case 27:return;
		
		}
	}
}
void Build()
{
	FILE *fp = fopen("boxmanmap.dat", "ab+");
	if(fp == 0){
		system("cls");
		printf("ERROR:δ֪����!");
		getch();
		return;
	}
	fseek(fp, 0, 0);
	fread(map, sizeof(map), 1, fp);
	fclose(fp);
	system("color F4");
	Bupdate();
}
void main()
{
	srand(time(NULL));
	system("mode con cols=34 lines=21");
	system("title ������");
	int choose = 0;
	while(1){
		system("color F0");
		system("cls");
		if(choose == 0)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0XF9);
		printf("\n	[S]��ʼ��Ϸ\n");
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0XF0);
		if(choose == 1)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0XF9);
		printf("	[B]�ؿ��༭\n");
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0XF0);
		if(choose == 2)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0XF9);
		printf("	[O]��Ϸ����\n");
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0XF0);
		printf("\n\n\n\t˵����\n\t������ƶ����˹���\n\t�����е������ƶ���\n\tָ��λ�á�\n\t[Ecs] �����ϼ�Ŀ¼\n  \n\n\n\n\t��Ȩ����");
		switch(Button()){
		case 's':
		case 'S':
			Read();
			break;
		case 'b':
		case 'B':
			Build();
			break;
		case 'o':
		case 'O':
			Set();
			break;
		case 'U':
			if(choose > 0)choose--;
			break;
		case 'D':
			if(choose < 2)choose++;
			break;
		case 13:
			if(choose == 0)Read();
			else if(choose == 1)Build();
			else if(choose == 2)Set();
		}
	}
}