// ������.cpp : �������̨Ӧ�ó������ڵ㡣
/*
�հ�0	����1	Ŀ��2	ǽ		������
0000	0001	0010	1000	0100
*/
#include "stdafx.h"
#include "stdafx.h"
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <time.h>
#include <string.h>
#pragma warning(disable:4996)
int map[100][17][17];
int level = 1;
void gotoxy(int x, int y)
{
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD pos;
	pos.X = x * 2;
	pos.Y = y;
	SetConsoleCursorPosition(hOut, pos);
}
char Button()
{
	char ch = getch();
	if(ch == -32)             //�����
	{
		ch = getch();
		if(ch == 72)return 'U';   //��
		if(ch == 80)return 'D';   //��
		if(ch == 75)return 'L';   //��
		if(ch == 77)return 'R';   //��
	}
	if(ch == 32)return ' ';	//�ո�
	return ch;
}
void Draw()
{
	gotoxy(0, 0);
	printf("�X�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�[");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�U                              �U");
	printf("�^�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�a");
	for(int j = 1; j < 17; j++)
	for(int i = 1; i < 17; i++){
		if(map[level][i][j] == 8){
			gotoxy(i, j);
			printf("��");
		}
		if(map[level][i][j] == 1){
			gotoxy(i, j);
			printf("��");
		}
		if(map[level][i][j] == 2){
			gotoxy(i, j);
			printf("��");
		}
		if(map[level][i][j] == 4){
			gotoxy(i, j);
			printf("��");
		}
	}
}
void Bclear(int x, int y, int map[100][17][17], int *box, int *place, int *men)
{
	if(map[level][x][y] == 1)(*box)--;
	if(map[level][x][y] == 2)(*place)--;
	if(map[level][x][y] == 4)(*men)--;
}
void Building()
{
	int box = 0;
	int place = 0;
	int men = 0;
	for(int j = 1; j <= 15; j++)
	for(int i = 1; i <= 15; i++){
		if(map[level][i][j] == 1)box++;
		if(map[level][i][j] == 2)place++;
		if(map[level][i][j] == 4)men++;
	}
	int x = 1, y = 1;
	gotoxy(x, y);
	printf("�I");
	gotoxy(0, 17);
	printf("[�س�]����[�ո�]ǽ��[X]��־λ��");
	gotoxy(0, 18);
	printf("[Esc]����[S]����[C]���[A]���˹�");
	while(1){
		int ox = x, oy = y;
		switch(Button()){
		case 'U':if(y > 1)y--; break;
		case 'D':if(y < 15)y++; break;
		case 'L':if(x > 1)x--; break;
		case 'R':if(x < 15)x++; break;
		case 'x':
		case 'X':
			Bclear(x, y, map, &box, &place, &men);
			place++;
			map[level][x][y] = 2; break;
		case 'a':
		case 'A':
			Bclear(x, y, map, &box, &place, &men);
			men++;
			map[level][x][y] = 4; break;
		case 13:
			Bclear(x, y, map, &box, &place, &men);
			box++;
			map[level][x][y] = 1; break;
		case ' ':
			Bclear(x, y, map, &box, &place, &men);
			map[level][x][y] = 8; break;
		case 'c':
		case 'C':
			Bclear(x, y, map, &box, &place, &men);
			map[level][x][y] = 0; break;
		case 27:return;
		case 's':
		case 'S':
			//fprintf(fp, "level\n");
			//fwrite(&map, 17 * 17, map[17][17], fp);
			FILE *fp = fopen("boxmanmap.dat", "wb");
			if(fwrite(map, sizeof(map), 1, fp) == 1)printf("д��ɹ�");
			fclose(fp);
			getch();
			return;
		}
		if(!(x == ox && y == oy)){
			gotoxy(x, y);
			printf("�I");
			gotoxy(ox, oy);
			if(map[level][ox][oy] == 1)printf("��");
			else if(map[level][ox][oy] == 2)printf("��");
			else if(map[level][ox][oy] == 8)printf("��");
			else if(map[level][ox][oy] == 0)printf("  ");
			else if(map[level][ox][oy] == 4)printf("��");
		}
		gotoxy(0, 19);
		printf("map[%2d][%2d]:%2d    box:%2d place:%2d", x, y, map[x][y], box, place);
	}
}
void Bupdate()
{
	while(1)
	{
		/*{
			gotoxy(0, 0);
			printf("�X�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�[");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�U                              �U");
			printf("�^�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�a");
			for(int j = 1; j <= 15; j++)
			for(int i = 1; i <= 15; i++){
				map[level][i][j] = 0;
			}
		}*/
		gotoxy(0, 18);
		printf("��%2d��", level);
		Draw();
		switch(Button()){
		case 'U':level++; break;
		case 'D':if(level>0)level--; break;
		case 13:
			Building();
			return;
		}
	}
}
void Build()
{
	FILE *fp = fopen("boxmanmap.dat", "rb");
	if(fp == 0){
		system("cls");
		printf("ERROR:δ֪����!");
		getch();
		return;
	}
	fseek(fp,0, 0);
	fread(map, sizeof(map), 1, fp);
	system("color F4");
	Bupdate();
}
void main()
{
	srand(time(NULL));
	system("mode con cols=34 lines=21");
	system("title �����ӵ�ͼ�༭��");
	while(1){
		system("cls");
		Build();
	}
}