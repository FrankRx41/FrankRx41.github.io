#ifndef _MAIN_H_
#define _MAIN_H_

struct mode
{
	int wide;
	int high;
	int x;
	int y;

	int spacing;

	int isok;
	int autonamed;
	int moremsg;
};
typedef struct mode mode;

void gotoxy(int x, int y);
void ClsFrame(int x,int y,int wide,int high);

void Option();
void Help();

#endif