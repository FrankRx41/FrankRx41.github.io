#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windows.h>
#include <string.h>
#include "matrix.h"
#include "main.h"
#include "file.h"

matrix mtx[MAX+10];
mode mod;
unsigned int count;
//ȷ����Ϣ
int isok()
{
	gotoxy(mod.x+2,mod.y+1);
    if(mod.isok==1)
    {
        char ch;
        printf("Yes or Not?(Y/N)");
        ch=getch();
        if(ch=='y'||ch=='Y')return 1;
        else return 0;
    }
    else return 1;
}
//�ƶ����
void gotoxy(int x, int y)
{
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD pos;
    pos.X = x;
    pos.Y = y;
    SetConsoleCursorPosition(hOut, pos);
}
//����
void ClsFrame(int x,int y,int wide,int high)
{
	int i,j;
	for(i=1;i<wide;i++)
    {
		for(j=1;j<high;j++)
		{
			gotoxy(x+i*2,y+j);
			printf("  ");
		}
    }
}
//���ƴ���
void MakeFrame(int x,int y,int wide,int high)
{
    int i;
    gotoxy(x,y);
    printf("�X");
	gotoxy(x+wide*2,y);
    printf("�[");
	gotoxy(x,y+high);
    printf("�^");
	gotoxy(x+wide*2,y+high);
    printf("�a");
    for(i=1;i<wide;i++)
    {
        gotoxy(x+i*2,y);
        printf("�T");
    }
    for(i=1;i<high;i++)
    {
        gotoxy(x,y+i);
        printf("�U");
    }
	for(i=1;i<wide;i++)
    {
        gotoxy(x+i*2,y+high);
        printf("�T");
    }
	for(i=1;i<high;i++)
    {
        gotoxy(x+wide*2,y+i);
        printf("�U");
    }
	printf("\n");
}
//�������
void PrintMatrix()
{
	int i,j;
	int l=0;
	gotoxy(mod.x,mod.y-1);
	printf("ID:%3d   Name:%-20s\n",count,mtx[count].name);
	for(i=0;i<mtx[count].row;i++)
	{
		for(j=0;j<mtx[count].column;j++)
		{
			gotoxy(mod.x+2+j*mod.spacing,mod.y+i+1);
			printf("%g",mtx[count].array[i][j]);
		}
	}
    /*for(l;l<mod.high-1;l++){
        if(l==mod.high-2)printf("\t\t\t\tֵ%3g\t��%3d",mtx[count].value,mtx[count].rank);
        printf("\n");
    }*/
}
//��ȡ����
double getg()
{
    char ch;
    double rs=0;
    double decimal=0;	//С���ĸ���
    int call=0;
	int negative=1;
    while(1)
    {
        ch=getch();
        if(call==0 && ch==13)
        {
            return 505;
        }
		if(call==0 && ch==8)
        {
            return 606;
        }
		if(call==0 && ch=='-')
        {
            negative=-1;
			printf("-");
        }
        else if(ch==27)
		{
			return 404;
		}
        else if(ch==8)
		{
			return 707;
		}
        else if(ch=='.')
        {
            decimal=1;
			printf(".");
        }
        else if(ch>='0'&&ch<='9')
        {
            if(decimal==0)
            {
                rs*=10;
                rs+=ch-'0';
            }
            else
            {
                decimal*=10;
                rs+=(ch-'0')/decimal;
            }
			printf("%c",ch);
        }
		else if(ch==13||ch==' ')
        {
            return rs*negative;
        }
        call++;
    }
}
//��ȡ����ID
int getid()
{
    char ch[20];
	int i;
	int rs=0;
	int str=0;	//�Ƿ�Ϊ��ĸ,Ĭ��Ϊ����
	int call=0;
    while(1)
    {
        ch[call]=getch();
		printf("%c",ch[call]);
        if(ch[call]==27)
		{
			return 404;
		}
        else if(ch[call]==8)
		{
			return 606;
		}
		else if(ch[call]>='a'&&ch[call]<='z' || ch[call]>='A'&&ch[call]<='Z')
		{
			str=1;		
		}
		else if(ch[call]>='0' && ch[call]<='9' && str==0)
		{
			rs*=10;
			rs+=ch[call]-'0';	
		}
		else if(ch[call]==13)
		{
			if(str==1)
			{
				int n;
				for(i=call;i<19;i++)
					ch[i]=' ';
				ch[19]='\0';
				//printf("ch=%s\n",ch);
				for(n=0;n<MAX;n++)if(mtx[n].row==0)break;
				for(i=0;i<n;i++)
				{
					//printf("%d=%s\n",i,mtx[i].name);
					if(strcmp(ch,mtx[i].name)==0)
						return i;
				}
				return -1;
			}
			else 
			{
				return rs;
			}
		}
		call++;
    }
}
//�½�����
void NamedMatrix()
{
	int i;
	char ch;
	ClsFrame(mod.x,mod.y,mod.wide,mod.high);
	gotoxy(mod.x+2,mod.y+1);
	printf("ID %3d   Named:",count);
	gotoxy(mod.x+2,mod.y+2);
	for(i=0;i<19;i++)
	{
		ch=getch();
		printf("%c",ch);
		if(ch==13)
		{
			int j;
			for(j=i;j<19;j++)
				mtx[count].name[j]=' ';
			mtx[count].name[19]='\0';
			return;
		}
		else 
		{
			mtx[count].name[i]=ch;
		}
	}
	//scanf("%s",mtx[count].name);
}
void AddMatrix()
{
    double temp;
    int i=0,j=0;
	int tr=mtx[count].row;
	int tc=mtx[count].column;
	ClsFrame(mod.x,mod.y,mod.wide,mod.high);
	gotoxy(mod.x+2,mod.y+1);
	mtx[count].row=0;
	mtx[count].column=0;
	mtx[count].name[0]=0;
	printf("ID %3d   NewMatrix:",count);
    while(1)
    {
		gotoxy(mod.x+2+j*6,mod.y+i+2);
		printf("    ");
		gotoxy(mod.x+2+j*6,mod.y+i+2);
        temp=getg();
        if(temp==606)
        {
            if(j==0 && i>0)
            {
                i--;
                j=mtx[count].column-1;
            }
            else
            {
                j--;
            }

        }
		else if(temp==707)
        {
        }
        else if(temp==505)
        {
            if(j==0)
            {
                mtx[count].row=i;
				if(mod.autonamed==1)
				{
					mtx[count].name[0]=count/100+'0';
					mtx[count].name[1]=(count%100)/10+'0';
					mtx[count].name[2]=count%10+'0';
					mtx[count].name[3]='\0';
				}
                return;	//����
            }
            i++;
            mtx[count].column=j;
            j=0;
        }
        else if(temp==404)
        {
            printf("cancel!");
			mtx[count].row=tr;
			mtx[count].column=tc;
            return;
        }
        else
        {
            //printf("%g",temp);
            mtx[count].array[i][j]=temp;
            j++;
			if(mtx[count].column!=0 && j==mtx[count].column)
			{
				i++;
				j=0;
			}
        }
    }
}
//ɾ������
void DelMatrix()
{
    int i=0,j=0;
	ClsFrame(mod.x,mod.y,mod.wide,mod.high);
	if(isok()==0)return;
	for(i=0;i<mtx[count].row;i++)
	{
		for(j=0;j<mtx[count].column;j++)
		{
			mtx[count].array[i][j]=0;
			mtx[count].row=0;
			mtx[count].column=0;
			mtx[count].name[0]='\0';
		}
	}
}
void DelAllMatrix()
{
    int i=0,j=0,n;
	ClsFrame(mod.x,mod.y,mod.wide,mod.high);
	if(isok()==0)return;
	for(n=0;n<MAX;n++)
	{
		for(i=0;i<mtx[n].row;i++)
		{
			for(j=0;j<mtx[n].column;j++)
			{
				mtx[n].array[i][j]=0;
				mtx[n].row=0;
				mtx[n].column=0;
				mtx[count].name[0]='\0';
			}
		}
	}
}
void FindMatrix()
{
	int find;
	ClsFrame(mod.x,mod.y,mod.wide,mod.high);
	gotoxy(mod.x+2,mod.y+1);
	printf("FindMartix:");
	while(1)
	{
		gotoxy(mod.x+2,mod.y+2);
		printf("          ");
		gotoxy(mod.x+2,mod.y+2);
		find=getid();
		if(find==404)
		{
			printf("cancel!");
			return;
		}
		if(find==606)
		{
			continue;
		}
		if(find>-1 && find<MAX)
		{
			count=find;
			return;
		}
		else
		{
			gotoxy(mod.x+2,mod.y+3);
			printf("can not find!");
			getch();
			return;
		}
		printf("\a");
	}
}
//�˵�
void menu()
{
	MakeFrame(mod.x,mod.y,mod.wide,mod.high);
	printf("  (A)����  (N)����  (C)����            \n");//(D)ɾ��
	printf("  (S)�洢  (L)��ȡ                    (B)��� \n");
	printf("  �T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T\n");
	printf("  (V)��ֵ  (R)����  (I)����  (E)����  (O)��� \n");
	printf("  (M)����  (D)���  (T)ת��  (U)��λ          \n");
	printf("  (+)�ӷ�  (-)����  (*)�˷�  (X)����          \n");
	printf("  �T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T\n");
	printf("  [Del]ɾ��   [F1]����   [F5]����   [F10]ѡ�� \n");
	printf("                         [F2]�ػ�   [Esc]�˳� \n");
	printf("  Version  beta   ");
	//system("date /T");
label:
	while(1)
	{
		char ch;
		ClsFrame(mod.x,mod.y,mod.wide,mod.high);
		PrintMatrix();
		gotoxy(0,0);
		ch=getch();
		if(ch==27)exit(0);
		if(ch=='a'||ch=='A')AddMatrix();
		if(ch=='n'||ch=='N')NamedMatrix();
		//if(ch=='d'||ch=='D')DelMatrix();
//����
		if(ch=='i'||ch=='I')
		{
			int n;
			if(mod.moremsg)
			{
				ClsFrame(mod.x,mod.y,mod.wide,mod.high);
				gotoxy(mod.x+2,mod.y+1);
				printf("Inverse:");
			}
			for(n=0;n<MAX;n++)if(mtx[n].row==0)break;
			Inverse(count,n);
			count=n;
		}
			

		if(ch=='u'||ch=='U')
		{
			int r;
			int temp;
			ClsFrame(mod.x,mod.y,mod.wide,mod.high);
			gotoxy(mod.x+2,mod.y+1);
			printf("UnitMatrix:");
			
			gotoxy(mod.x+2,mod.y+2);
			printf("row:");
			temp=getid();
			if(temp==404){
				printf("cancel!");
				goto label;
			}
			r=temp;
			
			UnitMatrix(r,count);
		}

		if(ch=='d'||ch=='D')
		{
			int id[1]={-1},t1,t2;
			int temp,n;
			ClsFrame(mod.x,mod.y,mod.wide,mod.high);
			gotoxy(mod.x+2,mod.y+1);
			printf("DisMantle:");
			
			gotoxy(mod.x+2,mod.y+2);
			printf("ID[0]:");
			temp=getid();
			if(temp==404){
				printf("cancel!");
				goto label;
			}
			id[0]=temp;
			
			gotoxy(mod.x+2,mod.y+3);
			printf("form:");
			temp=getid();
			if(temp==404){
				printf("cancel!");
				goto label;
			}
			t1=temp;
			
			gotoxy(mod.x+2,mod.y+4);
			printf("to:");
			temp=getid();
			if(temp==404){
				printf("cancel!");
				goto label;
			}
			t2=temp;
			
			for(n=0;n<MAX;n++)if(mtx[n].row==0)break;
			n=DisMantle(id[0],t1-1,t2-1,n);
			if(n!=-1)count=n;
			else if(mod.moremsg)
			{
				gotoxy(mod.x+2,mod.y+2+5);
				printf("can not DisMantle!");
				getch();
			}
		}

		if(ch=='o'||ch=='O')
		{
			int n;
			if(mod.moremsg)
			{
				ClsFrame(mod.x,mod.y,mod.wide,mod.high);
				gotoxy(mod.x+2,mod.y+1);
				printf("Oversimple:");
			}
			for(n=0;n<MAX;n++)if(mtx[n].row==0)break;
			Oversimple(count,n);
			count=n;
		}

		if(ch=='r'||ch=='R')
		{
			gotoxy(mod.x+2,mod.y+mod.high-1);
			printf("Rank:  %2d",Rank(count));
			getch();
		}

		if(ch=='v'||ch=='V')
		{
			gotoxy(mod.x+2,mod.y+mod.high-1);
			printf("Value:  %6g",Value(count));
			getch();
		}

		if(ch=='m'||ch=='M')
		{
			int id[2]={-1,-1};
			int temp,i=0,n;
			ClsFrame(mod.x,mod.y,mod.wide,mod.high);
			gotoxy(mod.x+2,mod.y+1);
			printf("Merge:");
			for(i=0;i<2;i++)
			{
				gotoxy(mod.x+2,mod.y+2+i);
				printf("ID[%d]:",i);
				temp=getid();
				if(temp==404){
					printf("cancel!");
					goto label;
				}
				id[i]=temp;
				//printf("%d",id[i]);
			}
			for(n=0;n<MAX;n++)if(mtx[n].row==0)break;
			n=Merge(id[0],id[1],n);
			if(n!=-1)count=n;
			else if(mod.moremsg)
			{
				gotoxy(mod.x+2,mod.y+2+i);
				printf("can not Merge!");
				getch();
			}
        }

		if(ch=='c'||ch=='C')
		{
			int id[1]={-1};
			int temp,n;
			ClsFrame(mod.x,mod.y,mod.wide,mod.high);
			gotoxy(mod.x+2,mod.y+1);
			printf("Copy:");

			gotoxy(mod.x+2,mod.y+2);
			printf("ID[0]:");
			temp=getid();
			if(temp==404){
				printf("cancel!");
				goto label;
			}
			id[0]=temp;

			gotoxy(mod.x+2,mod.y+3);
			printf("target:");
			temp=getid();
			if(temp==404){
				printf("cancel!");
				goto label;
			}
			n=temp;

			Copy(id[0],n);
			count=n;
        }

		if(ch=='e'||ch=='E')
		{
			int n;
			if(mod.moremsg)
			{
				ClsFrame(mod.x,mod.y,mod.wide,mod.high);
				gotoxy(mod.x+2,mod.y+1);
				printf("Echelon:");
			}
			for(n=0;n<MAX;n++)if(mtx[n].row==0)break;
			Echelon(count,n);
			count=n;
		}

		if(ch=='t'||ch=='T')
		{
			int n;
			if(mod.moremsg)
			{
				ClsFrame(mod.x,mod.y,mod.wide,mod.high);
				gotoxy(mod.x+2,mod.y+1);
				printf("Trans:");
			}
			for(n=0;n<MAX;n++)if(mtx[n].row==0)break;
			Trans(count,n);
			count=n;
		}

		if(ch=='x'||ch=='X')
		{
			int k;
			int temp,n;
			ClsFrame(mod.x,mod.y,mod.wide,mod.high);
			gotoxy(mod.x+2,mod.y+1);
			printf("Times:");

			gotoxy(mod.x+2,mod.y+2);
			printf("multiplicand:");
			temp=getid();
			if(temp==404){
				printf("cancel!");
				goto label;
			}
			k=temp;
			//printf("%d",k);

			for(n=0;n<MAX;n++)if(mtx[n].row==0)break;
			Times(count,k,n);
			count=n;
		}

        if(ch==45)
		{
			int id[2]={-1,-1};
			int temp,i=0,n;
			ClsFrame(mod.x,mod.y,mod.wide,mod.high);
			gotoxy(mod.x+2,mod.y+1);
			printf("Additive:");
			for(i=0;i<2;i++)
			{
				gotoxy(mod.x+2,mod.y+2+i);
				printf("ID[%d]:",i);
				temp=getid();
				if(temp==404){
					printf("cancel!");
					goto label;
				}
				id[i]=temp;
				//printf("%d",id[i]);
			}
			for(n=0;n<MAX;n++)if(mtx[n].row==0)break;
			n=Subtract(id[0],id[1],n);
			gotoxy(mod.x+2,mod.y+2+i);
			if(n!=-1)count=n;
			else printf("can not Additive");
		}

        if(ch=='*')
		{
			int id[2]={-1,-1};
			int temp,i=0,n;
			ClsFrame(mod.x,mod.y,mod.wide,mod.high);
			gotoxy(mod.x+2,mod.y+1);
			printf("Multiply:");
			for(i=0;i<2;i++)
			{
				gotoxy(mod.x+2,mod.y+2+i);
				printf("ID[%d]:",i);
				temp=getid();
				if(temp==404){
					printf("cancel!");
					goto label;
				}
				id[i]=temp;
				//printf("%d",id[i]);
			}
			for(n=0;n<MAX;n++)if(mtx[n].row==0)break;
			n=Multiply(id[0],id[1],n);
			gotoxy(mod.x+2,mod.y+2+i);
			if(n!=-1)count=n;
			else printf("can not Multiply");
        }

		if(ch=='+')
		{
			int id[2]={-1,-1};
			int temp,i=0,n;
			ClsFrame(mod.x,mod.y,mod.wide,mod.high);
			gotoxy(mod.x+2,mod.y+1);
			printf("Additive:");
			for(i=0;i<2;i++)
			{
				gotoxy(mod.x+2,mod.y+2+i);
				printf("ID[%d]:",i);
				temp=getid();
				if(temp==404){
					printf("cancel!");
					goto label;
				}
				id[i]=temp;
				//printf("%d",id[i]);
			}
			for(n=0;n<MAX;n++)if(mtx[n].row==0)break;
			n=Additive(id[0],id[1],n);
			gotoxy(mod.x+2,mod.y+2+i);
			if(n!=-1)count=n;
			else printf("can not Additive");
		}
//�ļ�����
		if(ch=='s'||ch=='S')
		{
			int flag=FileSave();
			if(mod.moremsg)
			{	
				ClsFrame(mod.x,mod.y,mod.wide,mod.high);
				gotoxy(mod.x+2,mod.y+1);
				if(flag)printf("Success!");
				else printf("Error!");
				getch();
			}
			
		}
		if(ch=='l'||ch=='L')
		{
			int flag=FileLoad();
			if(mod.moremsg)
			{	
				ClsFrame(mod.x,mod.y,mod.wide,mod.high);
				gotoxy(mod.x+2,mod.y+1);
				if(flag)printf("Success!");
				else printf("Error!");
				getch();
			}
		}
		if(ch=='b'||ch=='B')
		{
			DelAllMatrix();
			if(mod.moremsg)
			{
				ClsFrame(mod.x,mod.y,mod.wide,mod.high);
				gotoxy(mod.x+2,mod.y+1);
				printf("Success!");
				getch();
			}
		}

		if(ch==-32)
		{
			ch=getch();
			if(ch==72)if(count<MAX-1)count++;
			if(ch==80)if(count>0)count--;

			if(ch==75)if(count<MAX-11)count+=10;
			if(ch==77)if(count>9)count-=10;

			if(ch==83)DelMatrix();
		}
		else if(ch==0)
		{
			ch=getch();
			if(ch==59)Help();
			if(ch==60)
			{
				MakeFrame(mod.x,mod.y,mod.wide,mod.high);
				printf("  (A)����  (N)����  (C)����            \n");//(D)ɾ��
				printf("  (S)�洢  (L)��ȡ                    (B)��� \n");
				printf("  �T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T\n");
				printf("  (V)��ֵ  (R)����  (I)����  (E)����  (O)��� \n");
				printf("  (M)����  (D)���  (T)ת��  (U)��λ          \n");
				printf("  (+)�ӷ�  (-)����  (*)�˷�  (X)����          \n");
				printf("  �T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T\n");
				printf("  [Del]ɾ��   [F1]����   [F5]����   [F10]ѡ�� \n");
				printf("                         [F2]�ػ�   [Esc]�˳� \n");
				printf("  Version  beta   ");
			}
			if(ch==63)FindMatrix();
			if(ch==68)Option();
		}
	}
}
//������
int main()
{
	mod.isok=0;
	mod.wide=23;
	mod.high=12;
	mod.spacing=8;
	mod.x=0;
	mod.y=1;
	system("title Matrix Killer");
	system("color F9");
	system("mode con cols=48 lines=25");
	menu();
}
