#include "matrix.h"
#include <stdio.h>

extern matrix mtx[MAX];

int FileSave()
{
	int i,j,n,t;
	FILE *fp;
	for(t=MAX-1;t>=0;t--)
		if(mtx[t].row!=0)break;
	if(t==-1 || (fp=fopen("matrix.dat","w"))==0)return 0;
	for(n=0;n<=t;n++)
	{
		fprintf(fp,"ID:%3d      name:%-20s   row:%3d   column:%3d\n",n,mtx[n].name,mtx[n].row,mtx[n].column);
		for(i=0;i<mtx[n].row;i++)
		{
			for(j=0;j<mtx[n].column;j++)
			{
				fprintf(fp,"%6g",mtx[n].array[i][j]);
			}
			fprintf(fp,"\n");
		}
		fprintf(fp,"\n");
	}
	fclose(fp);	//�ر��ļ�����ֹ���ݶ�ʧ
	return 1;
}

int FileLoad()
{
	int i,j,n;
	FILE *fp;
    if((fp=fopen("matrix.dat","r"))==0)return 0;
	while(!feof(fp))
	{
		fscanf(fp,"ID:%3d      name:",&n);
		fgets(mtx[n].name,20,fp);
		fscanf(fp,"   row:%3d   column:%3d\n",&mtx[n].row,&mtx[n].column);
		for(i=0;i<mtx[n].row;i++)
		{
			for(j=0;j<mtx[n].column;j++)
			{
				fscanf(fp,"%lf",&mtx[n].array[i][j]);
			}
			fscanf(fp,"\n");
		}
		fscanf(fp,"\n");
	}
	return 1;
}