#include "matrix.h"
#include <stdio.h>

extern matrix mtx[MAX];
//��λ
void UnitMatrix(const int r,const int n)
{
	int i,j;
	mtx[n].column=mtx[n].row=r;
	for(i=0;i<mtx[n].row;i++)
	{
		for(j=0;j<mtx[n].column;j++)
		{
			if(i==j)
			{
				mtx[n].array[i][j]=1;
			}
			else 
			{
				mtx[n].array[i][j]=0;
			}
		}
	}
}
//����
int Merge(const int a,const int b,const int n)
{
	int i,j;
	if(mtx[a].row!=mtx[b].row || mtx[a].column!=mtx[b].column)
		return -1;
	mtx[n].row=mtx[a].row;
	mtx[n].column=mtx[a].column+mtx[b].column;
	for(i=0;i<mtx[n].row;i++)
	{
		for(j=0;j<mtx[n].column;j++)
		{
			if(j<mtx[a].row)
			{
				mtx[n].array[i][j]=mtx[a].array[i][j];
			}
			else
			{
				mtx[n].array[i][j]=mtx[b].array[i][j-mtx[a].row];
			}
		}
	}
	return n;
}
//���
int DisMantle(const int a,const int t1,const int t2,const int n)
{
	int i,j;
	if(mtx[a].column<t2 || t1>=t2 || t1<0)
		return -1;
	mtx[n].row=mtx[a].row;;
	mtx[n].column=t2-t1+1;
	for(i=0;i<mtx[a].row;i++)
	{
		for(j=0;j<mtx[a].column;j++)
		{
			if(j>=t1 && j<=t2)
			{
				mtx[n].array[i][j-t1]=mtx[a].array[i][j];
			}
		}
	}
	return n;
}
//����
void Copy(const int a,const int n)
{
	int i,j;
	mtx[n].row=mtx[a].row;
	mtx[n].column=mtx[a].column;
	for(i=0;i<mtx[n].row;i++)
	{
		for(j=0;j<mtx[n].column;j++)
		{
			mtx[n].array[i][j]=mtx[a].array[i][j];
		}
	}
}
//��ֵ
int Different(const int k[],const int n)
{
    int i,j;
    for(i=0; i<n-1; i++)
        for(j=i+1; j<n; j++)
        {
            if(k[i]==k[j])
            {
                return 0;
            }
        }
    return 1;
}
int Tao(const int k[],const int n)
{
	int i,j,s=0;
	for(i=0;i<n-1;i++)
		for(j=i;j<n;j++)
		if(k[i]<k[j])s++;
	if(n>3)
	{
		if(s%2==0)return 1;
		else return -1;
	}
	else
	{
		if(s%2==0)return -1;
		else return 1;
	}
}
void LopFor(double a[][10],int n,int k[],double *v,const int x)
{
    if(n<1)
    {
        if(Different(k,x))
        {
            double m=1;
            int i;
            for(i=0;i<x;i++)
            {
                m*=a[i][k[i]];
            }
            m*=Tao(k,x);
            *v+=m;
        }
    }
    else
    {
        for(k[n-1]=0; k[n-1]<x; k[n-1]++)
        {
			LopFor(a,n-1,k,v,x);
        }
    }
}
double Value(int a)
{
	double v=0;
	int k[10];
	int n=mtx[a].row;
	LopFor(mtx[a].array,n,k,&v,n);
	return v;
}
//����
void Echelon(const int a,const int n)
{
	int i,j,k;
	int row=0;
	int flag=0;
	double temp;
	mtx[n].row=mtx[a].row;
	mtx[n].column=mtx[a].column;
	for(i=0;i<mtx[n].row;i++)
	{
		for(j=0;j<mtx[n].column;j++)
		{
			mtx[n].array[i][j]=mtx[a].array[i][j];
		}
	}

	for(j=0;j<mtx[n].column;j++)
	{	
		//����
		if(mtx[n].array[row][j]==0)
		for(i=row+1;i<mtx[n].row;i++)
		{
			if(mtx[n].array[i][j]!=0)
			{
				for(k=0;k<mtx[n].column;k++)
				{
					temp=mtx[n].array[row][k];
					mtx[n].array[row][k]=mtx[n].array[i][k];
					mtx[n].array[i][k]=temp;
				}
			}
		}
		//��
		for(i=row+1;i<mtx[n].row;i++)
		{
			if(mtx[n].array[i][j]!=0)
			{
				temp=mtx[n].array[row][j]/mtx[n].array[i][j];
				for(k=0;k<mtx[n].column;k++)
				{
					mtx[n].array[i][k]*=temp;
				}
			}
		}
		//��
		for(i=row+1;i<mtx[n].row;i++)
		{
			if(mtx[n].array[i][j]!=0)
			{
				for(k=0;k<mtx[n].column;k++)
					mtx[n].array[i][k]-=mtx[n].array[row][k];
			}
		}
		//row�ж�
		for(i=row;i<mtx[n].row;i++)
		{
			if(mtx[n].array[i][j]==0)
			{
				row=i;
				break;
			}
		}
		
	}
}
//���
void Oversimple(const int a,const int n)
{
	int i,j,k,l;
	double temp;
	Echelon(a,n);
	//����һ�е�Ԫ�ر�Ϊ���
	if(mtx[n].array[0][0]!=0)
	{
		temp=1/mtx[n].array[0][0];
		for(k=0;k<mtx[n].column;k++)
		{
			mtx[n].array[0][k]*=temp;
		}
	}
	//����������
	for(i=1;i<mtx[n].row;i++)
    {
        j=0;
        while(j<mtx[n].column && i<mtx[n].row && mtx[n].array[i][j]==0)
        {
            j++;
        }
		for(l=0;l<i;l++)
		{
			if(mtx[n].array[l][j]!=0)
			{
				//��
				temp=mtx[n].array[l][j]/mtx[n].array[i][j];
				for(k=0;k<mtx[n].column;k++)
				{
					mtx[n].array[i][k]*=temp;
				}
				//printf("array[%d][%d]=%g  temp=%g\n",i,j,mtx[n].array[i][j],temp);
				//getch();
				//��
				for(k=0;k<mtx[n].column;k++)
				{
					mtx[n].array[l][k]-=mtx[n].array[i][k];
				}
			}
		}
		//��������λ���1
        if(mtx[n].array[i][j]!=0)
        {
			temp=1/mtx[n].array[i][j];
			for(k=0;k<mtx[n].column;k++)
			{
				mtx[n].array[i][k]*=temp;
			}
        }
    }
}
//����
int Rank(const int a)
{
	int i,j;
	int flag;
	int rank=mtx[a].row;
	int n=100;
	Echelon(a,n);
	for(i=0;i<mtx[n].row;i++)
    {
        flag=1;
        for(j=0;j<mtx[n].column;j++)
            if(mtx[n].array[i][j]!=0)flag=0;
        if(flag==1)rank--;
    }
	return rank;
}
//����
int Inverse(const int a,const int n)
{
	int x1=101;
	int x2=102;
	int x3=103;
	if(mtx[a].row!=mtx[a].column)
		return -1;
	UnitMatrix(mtx[a].row,x1);
	//printf("1\n");
	Merge(a,x1,x2);
	//printf("2\n");
	Oversimple(x2,x3);
	//printf("3\n");
	DisMantle(x3,mtx[a].row,mtx[a].row*2-1,n);
	return n;
}
//�˷�
int Multiply(const int a,const int b,const int n)
{
	int i,j,k;
	if(mtx[a].row!=mtx[b].column || mtx[a].column!=mtx[b].row)
		return -1;
	mtx[n].row=mtx[a].row;
	mtx[n].column=mtx[b].column;
	for(i=0;i<mtx[n].row;i++)
	{
		for(j=0;j<mtx[n].column;j++)
		{
			mtx[n].array[i][j]=0;
			for(k=0;k<mtx[b].row;k++)
			mtx[n].array[i][j]+=mtx[a].array[i][k]*mtx[b].array[k][j];
		}
	}
	return n;
}
//�ӷ�
int Additive(const int a,const int b,const int n)
{
	int i,j;
	if(mtx[a].row!=mtx[b].row || mtx[a].column!=mtx[b].column)
		return -1;
	mtx[n].row=mtx[a].row;
	mtx[n].column=mtx[b].column;
	for(i=0;i<mtx[n].row;i++)
		for(j=0;j<mtx[n].column;j++)
		{
			mtx[n].array[i][j]=mtx[a].array[i][j]+mtx[b].array[i][j];
		}
		return n;
}
//����
int Subtract(const int a,const int b,const int n)
{
	int i,j;
	if(mtx[a].row!=mtx[b].row || mtx[a].column!=mtx[b].column)
		return -1;
	mtx[n].row=mtx[a].row;
	mtx[n].column=mtx[b].column;
	for(i=0;i<mtx[n].row;i++)
		for(j=0;j<mtx[n].column;j++)
		{
			mtx[n].array[i][j]=mtx[a].array[i][j]-mtx[b].array[i][j];
		}
		return n;
}
//ת��
void Trans(const int a,const int n)
{
	int i,j;
	mtx[n].row=mtx[a].column;
	mtx[n].column=mtx[a].row;
	for(i=0;i<mtx[n].row;i++)
	{
		for(j=0;j<mtx[n].column;j++)
			mtx[n].array[i][j]=mtx[a].array[j][i];
	}
}
//����
void Times(const int a,const int k,const int n)
{
	int i,j;
	mtx[n].row=mtx[a].row;
	mtx[n].column=mtx[a].column;
	for(i=0;i<mtx[n].row;i++)
	{
		for(j=0;j<mtx[n].column;j++)
			mtx[n].array[i][j]=k*mtx[a].array[i][j];
	}
}
