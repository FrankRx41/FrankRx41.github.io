#ifndef _MATRIX_H_
#define _MATRIX_H_

#define MAX 100

struct matrix
{
	char name[20];
	double array[10][10];
	int row;
	int column;
	int rank;
	double value;
};

typedef struct matrix matrix;

int Merge(const int a,const int b,const int n);
void Copy(const int a,const int n);
int DisMantle(const int a,const int t1,const int t2,const int n);
void UnitMatrix(const int r,const int n);

int Additive(const int a,const int b,const int n);
int Subtract(const int a,const int b,const int n);
void Trans(const int a,const int n);
void Times(const int a,const int k,const int n);
int Multiply(const int a,const int b,const int n);
int Rank(const int a);
void Echelon(const int a,const int n);
void Oversimple(const int a,const int n);
int Inverse(const int a,const int n);
double Value(int a);


#endif
